package com.katelondemocura.scripts;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.katalondemocura.ib.cura_page1;
import com.katalondemocura.ib.cura_page11;


public class TestScript001 {
	
	
  WebDriver driver = new ChromeDriver();
  // Page objects
	cura_page1 cpage1 = new cura_page1();
	//cura_page2 cpage2= new cura_page2();
	cura_page11 cpag11 = new cura_page11();
	
  @Test(priority=1)
  public void  InvokeApp() {
	  cpage1.cura_page1_init(driver);
	  
	  cpage1.LaunchApp("https://katalon-demo-cura.herokuapp.com/");
	 
	  // complete your assertion
  }
  
  @Test(priority=2)
  public void Click_Make_Appointment() {
	  
	cpage1.Click_On_Make_An_Appointment();
	//assert
	
	  
  }
  
  @Test(priority=3)
  
  public void PerformLogin_User() throws IOException {
	  cpag11.init_cura_page11(driver);
	  cpag11.Enter_Name_Login();
  }
  
  
}
