package com.katalondemocura.ib;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class cura_page11 {
	
	WebDriver driver;
	FileReader fr;
	Properties p = new Properties();
	
	
	// Locators
	
	By unm = By.name("username");
	
	public void init_cura_page11(WebDriver driver) {
		this.driver=driver;
		
	}
	
	public void Enter_Name_Login() throws IOException {
		String path1 = "D://Java_Programming_2025_2026_Gayatri//TestingMGMetaGeeksPUN_GM_ScenariosBased_Selenium6_POM//TestData//datatest.properties";
		fr = new FileReader(path1);
		p.load(fr);
		//System.out.println("value of p is: " + " " + p);
		
		driver.findElement(unm).sendKeys(p.getProperty("username1"));
		System.out.println(p.getProperty("username1"));
		System.out.println(p.getProperty("password1"));
		
	}

}
