package com.katalondemocura.ib;

import java.io.IOException;

public class ReadDataAccess {
	public static void main(String[] args) throws IOException {
		ExcelRead obj = new ExcelRead();
		String val=obj.ReadCellData1(2, 2);
		
		System.out.println(val);
	}

}
