package com.katalondemocura.ib;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

//documentation for POM

// init
//locators
//steps automation methods

public class cura_page1 {
	WebDriver driver;
	
	// init
	
	
	// Locators
	
	By validatePg1 
	= By.xpath("//*[contains(text(),'We Care About Your Health')]");
	By mkap = By.id("btn-make-appointment");
	By mkappform = By.xpath("//h2[contains(text(),'Make Appointment')]");
	
	public void cura_page1_init(WebDriver driver) {
		this.driver=driver;
	}
	
	//automation steps methods
	
	public void LaunchApp(String BaseURL) {
		driver.get(BaseURL);
		String val1 = "The app is launched successfully";
		String val2 = "Check the url again !";
		
		if(driver.findElement(mkap).isDisplayed()) {
			System.out.println("The app is launched successfully");
			//return val1;
		}
		else {
			System.out.println("Check the url again !");
			//return val2;
		}
		
	}
	
	public void Click_On_Make_An_Appointment() {
		
		driver.findElement(mkap).click();
		//String mkaptext=driver.findElement(mkappform).getText();
		
		//return mkaptext;
		
	}
	
	
	

}
