package com.seleniumay1.lib;

import org.openqa.selenium.WebDriver;

public class SeleniumDay1_Lib {
	WebDriver driver;
	
	public void init(WebDriver driver) {
		this.driver=driver;
	}
	// To invoke the app
	public void InvokeAwesomeQaApp() {
		driver.get("https://www.awesomeqa.com/ui");
	}
	// Extract the page title
	public String AwesomeHome_PageTitle() {
		String pgTitleHome=driver.getTitle();
		return pgTitleHome;
	}
	
	
	
	

}
