package com.libBase.Test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class t1 extends BaseData {
	
 
  
  t1(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

  @Test
  public void f(WebDriver driver) {
	  driver.get("https://www.google.com");
	  
	  
  }
}
