package com.libBase.Test;

import org.testng.annotations.Test;

public class t1Test {
  @Test
  public void f() {
  }
}
