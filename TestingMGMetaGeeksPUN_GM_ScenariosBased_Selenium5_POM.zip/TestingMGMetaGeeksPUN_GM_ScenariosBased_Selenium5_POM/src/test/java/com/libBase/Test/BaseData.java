package com.libBase.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseData {
	protected static WebDriver driver;
	BaseData(WebDriver driver){
		driver=new ChromeDriver();
		

    
     }
}
