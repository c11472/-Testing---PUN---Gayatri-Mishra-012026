package com.scripts.day7;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class TC_ImplicitWait_Demo {
  WebDriver driver=new ChromeDriver();
  @Test(priority=1)
  public void ImplicitWaitDemo() {
	  //  driver = new ChromeDriver();
	  driver.get("https://www.awesomeqa.com/ui");
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	  WebElement num = driver
			  .findElement(By.xpath("//*[contains(text(),'1234567810')]"));
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

	  String phnum=num.getText();
	  System.out.println(phnum);	  
  }
  
  
  @Test(priority=2)
  public void ConditionalWait()
   {
	  driver.get("https://www.orangetravels.in/#/");
	  WebElement can = 
			  driver.findElement(By.xpath("//button[@data-dismiss='modal']"));
	  
	  WebDriverWait wait = 
			  new WebDriverWait(driver,Duration.ofSeconds(20));
	  
	  wait.until(ExpectedConditions.visibilityOf(can)).click();
   }
 
 }
  
