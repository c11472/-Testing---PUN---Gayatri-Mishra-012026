package com.seleniumScenarios.scripts;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import com.seleniumScenarios.lib1.seleniumScenarios1;

public class seleniumScenarios1_Access {
	
  WebDriver driver = new FirefoxDriver();
  seleniumScenarios1 ssc = new seleniumScenarios1();
  @Test(priority=1)
  public void f() throws InterruptedException {
	ssc.init(driver);
	List<String> FinalOptions=  ssc.searchOptions();
	System.out.println(FinalOptions);
	  
	  
  }
  
  @Test(priority=2)
  public void TableData() {
	  ssc.init(driver);
	  ssc.Extract_Table_Data();
	  
  }
 
  @Test(priority=3)
  public void Extract_Data_DropDown() throws InterruptedException {
			ssc.Select_Drop_List_Data();
	 
	// System.out.println(lstResult);
  }
  
  @Test(priority=4)
  public void SelectIndex() throws InterruptedException {
	  ssc.init(driver);
	  ssc.SelectByIndexTest();
	  
  }
  
  @Test(priority=5)
  public void ExtractAlertMessage() throws InterruptedException {
	  ssc.init(driver);
	  String actAlert=ssc.Extract_HandelAlert_Message();
	  System.out.println("Alert message is : " + " " + actAlert);
	  
  }
}
