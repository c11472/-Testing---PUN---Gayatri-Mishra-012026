package com.seleniumScenarios.lib1;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class seleniumScenarios1 {
	
	WebDriver driver;
	public void init(WebDriver driver) {
		this.driver=driver;	
	}
	
	public List <String> searchOptions() throws InterruptedException{
		
		driver.get("https://www.google.com");
		Thread.sleep(2000);
		
		driver.findElement(By.name("q")).sendKeys("Test automation");
		Thread.sleep(2000);

		
		List<WebElement> options = 
				driver.findElements(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[2]/div[4]/div[2]/div[1]/div/ul/li"));
		List<String> resultsOptions= new ArrayList();
		for(int i=0;i<options.size();i++) {
			Thread.sleep(300);
			String result = options.get(i).getText();
			System.out.println(result);
			resultsOptions.add(result);		
		}
		return resultsOptions;
	}
	
public List<WebElement> Extract_Table_Data(){
	driver.get("https://www.w3schools.com/html/html_tables.asp");
	
	List <WebElement> dataList =
			driver.findElements(By.xpath("//table[@id='customers']//tr/td"));
	
	for(int i=0;i<dataList.size();i++)
	{
		String dataAct = dataList.get(i).getText();
		System.out.println(dataAct);
	
	}
	 return dataList;    
}


public List<WebElement> Select_Drop_List_Data() throws InterruptedException{
	driver.get("https://www.amazon.in/");
	
	Thread.sleep(2000);
	
     WebElement elements = 
    		 driver.findElement(By.xpath("//select[@id='searchDropdownBox']"));	
     Select sel = new Select(elements);
     Thread.sleep(3000);
   
    // sel.selectByIndex(3);
     
     //sel.selectByVisibleText("Baby");
     
     //sel.selectByValue("search-alias=amazon-devices");
     
     
     List<WebElement> myList = sel.getOptions();
	
	 for(int i=0;i<myList.size();i++) {
		 String values = myList.get(i).getText();
		 System.out.println(values);
	 }
	 //Thread.sleep(2000);
	 //sel.selectByVisibleText("Baby");*/
	 return myList;
}

public void SelectByIndexTest() throws InterruptedException {
	driver.get("https://demo.guru99.com/test/newtours/register.php");
	Thread.sleep(2000);

	WebElement elements2 = driver.findElement(By.name("country"));
	Select selTest = new Select(elements2);
	
	Thread.sleep(2000);
	
	selTest.selectByIndex(3);
	
	elements2.click();
	selTest.selectByVisibleText("data");
   }


public String Extract_HandelAlert_Message() throws InterruptedException {
	driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
	
	Thread.sleep(3000);
	WebElement unm = 
			driver.findElement(By.name("login"));
	WebElement pwd = 
			driver.findElement(By.id("password"));
	WebElement submessage = driver.findElement(By.xpath("//button[@type='submit']"));
	Thread.sleep(2000);
	driver.findElement(By.name("login")).sendKeys("testdata1");
	submessage.click();
	
	Alert act = driver.switchTo().alert();
	Thread.sleep(4000);

	String Act_AlertMessage=act.getText();
	
	Thread.sleep(2000);
	
	act.accept(); // Accepting the alert
	
	Thread.sleep(2000);
	unm.sendKeys("gayatridata");
	return Act_AlertMessage;
	
  }
	
}


