package com.AccessSeleniumDay1_Lib;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.seleniumay1.lib.SeleniumDay1_CommonMethods;
import com.seleniumay1.lib.SeleniumDay1_Lib;

import junit.framework.Assert;

public class Awesome_TC_01 {
  // create the browser instance
  WebDriver driver=new ChromeDriver();
  
  //Expected List
  
  List ExpList = Arrays.asList("bbsr","urrtt");
  
  //Object for Lib class
  SeleniumDay1_CommonMethods pg0 = new SeleniumDay1_CommonMethods();
  SeleniumDay1_Lib pg1 = new SeleniumDay1_Lib();
  
  //Expected Test Data
  String Exp_HomePgTitleIs="Your Store";
  
  @Test(priority=1)
  public void InvokeApp_Awesome() {
	  pg0.init0(driver);
	  pg0.Maximize_Browser_Window();
	  pg0.Delete_Cookeies_From_BrowserWindow();
	  pg1.init(driver);
	  pg1.InvokeAwesomeQaApp();	
	// String HomePgTitleIs = pg1.AwesomeHome_PageTitle();
	// System.out.println("HomePgTitleIs" + " " + HomePgTitleIs);
  }
  
  @Test(priority=2)
  public void Fetch_And_Validate_Title() {
	  String HomePgTitleIs = pg1.AwesomeHome_PageTitle();
	  System.out.println("HomePgTitleIs" + " " + HomePgTitleIs);
	 
	  // Assertion for validating page title
	  
	  Assert.assertEquals(HomePgTitleIs, Exp_HomePgTitleIs);
  }
  
  
  @Test(priority=3)
  public void Count_Links_Test() throws InterruptedException {
	  List lstData=pg1.Count_links_From_HomePage();
	  //System.out.println("Total number of links : " + " " +cnt);
	  Assert.assertEquals(ExpList, lstData);
	  	  
  }
  

}
