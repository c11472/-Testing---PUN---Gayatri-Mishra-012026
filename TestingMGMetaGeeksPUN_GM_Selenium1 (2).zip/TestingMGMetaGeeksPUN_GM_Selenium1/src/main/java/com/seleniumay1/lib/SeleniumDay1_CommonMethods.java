package com.seleniumay1.lib;

import org.openqa.selenium.WebDriver;

public class SeleniumDay1_CommonMethods {
	
	WebDriver driver ;
	
	public void init0(WebDriver driver) {
		
		this.driver=driver;
		
	}
	
	// Maximize the browser window
	
	public void Maximize_Browser_Window() {
		driver.manage().window().maximize();
	}
	
	//Delete all cookies
	
	public void Delete_Cookeies_From_BrowserWindow() {
		driver.manage().deleteAllCookies();
	}
	
	//Browser navigation
	public void Navigate_Back() {
		driver.navigate().back();
		
	}
	
	//Extract Page source
	public String Extract_PageSource_Content() {
		String pgs=driver.getPageSource();
		return pgs;
	}
	
	
	
	public void Navigate_Forward() {
		driver.navigate().forward();
	}
	
	public void Navigate_Refresh() {
		driver.navigate().refresh();
	}

}


