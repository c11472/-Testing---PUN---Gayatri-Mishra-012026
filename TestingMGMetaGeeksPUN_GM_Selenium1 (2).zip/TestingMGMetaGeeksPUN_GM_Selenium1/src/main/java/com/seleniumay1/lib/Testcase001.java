package com.seleniumay1.lib;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Testcase001 {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		// Invoke the app
		
		driver.get("https://www.awesomeqa.com/ui");
		
		// Validate Title
		
		String PgTitle1=driver.getTitle();
		System.out.println(PgTitle1);
		
	}

}

