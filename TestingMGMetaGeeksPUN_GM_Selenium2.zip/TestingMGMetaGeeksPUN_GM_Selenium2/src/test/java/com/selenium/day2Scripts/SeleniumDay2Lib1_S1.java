package com.selenium.day2Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.seleniumd.day2Lib.SeleniumDay2Lib1;

import junit.framework.Assert;

public class SeleniumDay2Lib1_S1 {
	
	
	WebDriver driver = new ChromeDriver();
	// Class objects
	SeleniumDay2Lib1 sd2lib = new SeleniumDay2Lib1();
	//Expected Data
	String ExpStr="My Orders";
	String ExpError = "Warning: No match for E-Mail Address and/or Password.";
	
  @Test(priority=1)
  public void Test_Launch() throws InterruptedException {
	  sd2lib.init(driver);
	  sd2lib.Launch_OcartLogin();
	  Thread.sleep(3000);

  }
	
  @Test(priority=2)
  public void Test_Login_Validate() throws InterruptedException {
	 
	  String ActStr=sd2lib.Perform_Login_Valid("gayatrimis2@gmail.com"
			  ,"gayatrimis2@gmail.com");//passing test data during method call
	  Assert.assertEquals(ExpStr, ActStr);
	  
	 
		  
	  }
  
  @Test(priority=3)
  public void Test_LoginInvalid_Validate() throws InterruptedException {
	  
	  String ActError = sd2lib.Perform_Login_Invalid("c344", "5573");// invalid data
	  
	  Assert.assertEquals(ExpError, ActError);
  }
  
   }

