package com.seleniumd.day2Lib;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class SeleniumDay2Lib1 {
	WebDriver driver;
	// init method
	public void init(WebDriver driver) {
		this.driver=driver;
		
	}
	
	public String Launch_OcartLogin() {
		
		driver.get("https://awesomeqa.com/ui/index.php?route=account/login");
		String LoginPageTitle=driver.getTitle();
		return LoginPageTitle;	
	}
	
	public String Perform_Login_Valid(String email,String password) throws InterruptedException {
		
		
		driver.findElement(By.xpath("//input[@id='input-email']")).sendKeys(email);
		//driver.findElement(By.xpath("//input[@id='input-email']")).sendKeys("gayatrimis2@gmail.com");

		driver.findElement(By.xpath("//input[@id='input-password']"))
		.sendKeys(password);
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		String confirmation_message=driver
				.findElement(By.xpath("//h2[contains(text(),'My Orders')]"))
				.getText();
		Thread.sleep(4000);
		Actions act = new Actions(driver);
		WebElement el = 
				driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/i"));
		act.moveToElement(el).click().build().perform();
		//driver.findElement(By.xpath("")).click();
		
		Thread.sleep(20000);
		// click on Logout
		WebElement el1 = 
				driver.findElement(By.xpath("(//a[contains(text(),'Logout')])[1]"));
		el1.click();
		Thread.sleep(3000);

		return confirmation_message;
		
	}
	
	public String Perform_Login_Invalid(String email1,String password1) throws InterruptedException {
		/*WebElement el_continue = driver.findElement(By.xpath("//*[contains(text(),'Continue')]"));
		Thread.sleep(2000);
		el_continue.click();*/
		
		WebElement el_AccountLink = driver.findElement(By.xpath("(//a[contains(text(),'Account')])[2]"));
		el_AccountLink.click();
		driver.findElement(By.xpath("//input[@id='input-email']")).sendKeys(email1);
		//driver.findElement(By.xpath("//input[@id='input-email']")).sendKeys("gayatrimis2@gmail.com");

		driver.findElement(By.xpath("//input[@id='input-password']")).sendKeys(password1);
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(3000);
		WebElement errmsg = driver.findElement(By.xpath("//*[@id='account-login']/div[1]"));
		Thread.sleep(2000);
		String confirmation_error_message=errmsg .getText();
		return confirmation_error_message;
	}
}
